INSERT INTO Accounts (AccountName, AccountType, Balance)
VALUES
('Kumar', 'USER', 5000.00),
('Anita', 'USER', 2500.00),
('AmazonStore', 'MERCHANT', 10000.00),
('FlipkartStore', 'MERCHANT', 8000.00);

SELECT * FROM Accounts;