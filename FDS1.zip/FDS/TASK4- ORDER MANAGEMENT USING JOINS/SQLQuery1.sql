CREATE DATABASE OrderManagementDB;
GO

USE OrderManagementDB;
GO