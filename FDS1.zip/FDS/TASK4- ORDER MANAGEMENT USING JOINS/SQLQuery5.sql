INSERT INTO Customers VALUES
(1, 'Alice', 'alice@gmail.com'),
(2, 'Bob', 'bob@gmail.com'),
(3, 'Charlie', 'charlie@gmail.com');

INSERT INTO Products VALUES
(101, 'Laptop', 60000),
(102, 'Mobile', 25000),
(103, 'Headphones', 3000);

INSERT INTO Orders VALUES
(1001, 1, 101, 1, '2024-01-10'),
(1002, 1, 102, 2, '2024-01-12'),
(1003, 2, 103, 3, '2024-01-15'),
(1004, 3, 101, 1, '2024-01-20');