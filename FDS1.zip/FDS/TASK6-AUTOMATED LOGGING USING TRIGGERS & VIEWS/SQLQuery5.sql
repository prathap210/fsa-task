INSERT INTO Employees VALUES (1, 'John Doe', 50000);

SELECT * FROM Employees;