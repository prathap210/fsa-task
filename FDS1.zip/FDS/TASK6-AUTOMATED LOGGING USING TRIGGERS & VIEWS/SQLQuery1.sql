DROP TABLE Employees;

CREATE TABLE Employees (
 EmpID INT PRIMARY KEY,
 Name VARCHAR(100),
 Salary DECIMAL(10,2)
);