UPDATE Employees
SET Salary = 55000
WHERE EmpID = 1;